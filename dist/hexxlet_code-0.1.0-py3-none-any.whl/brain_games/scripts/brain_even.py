#!/usr/bin/env python3

from brain_games.even_or_odd import greeting


def main():
    greeting()


if __name__ == "__main__":
    main()
