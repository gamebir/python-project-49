#!/usr/bin/env python3
from brain_games.games.brain_progr import brain_progr


def main():
    brain_progr()


if __name__ == "__main__":
    main()

